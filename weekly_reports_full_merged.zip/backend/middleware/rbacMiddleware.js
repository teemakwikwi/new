export function requirePermission(permission) {
  return (req, res, next) => {
    if (!req.user) return res.status(403).json({ message: 'Unauthorized' });
    if (req.user.isAdmin) return next();
    // In production, check user's permissions from DB or token
    return next();
  };
}