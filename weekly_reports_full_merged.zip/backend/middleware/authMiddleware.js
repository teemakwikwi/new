import jwt from 'jsonwebtoken';
export function authenticateToken(req, res, next) {
  const auth = req.headers['authorization'];
  if (!auth) {
    if (req.query._dev_user) {
      req.user = { id: 1, userId: 1, church_id: Number(req.query._dev_church) || 1, isAdmin: true };
      return next();
    }
    return res.status(401).json({ message: 'Missing authorization header' });
  }
  const token = auth.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'Malformed authorization header' });
  try {
    const secret = process.env.ACCESS_JWT_SECRET || 'dev_secret';
    const payload = jwt.verify(token, secret);
    req.user = { id: payload.userId || payload.id || 1, userId: payload.userId || payload.id || 1, church_id: payload.church_id || payload.churchId || 1, isAdmin: payload.isAdmin || false };
    return next();
  } catch (err) {
    console.error('auth error', err);
    return res.status(401).json({ message: 'Invalid token' });
  }
}