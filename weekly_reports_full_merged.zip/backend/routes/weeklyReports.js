import express from 'express';
import {
  previewAbsentees, createWeeklyReport, listWeeklyReports, getWeeklyReportDetails,
  updateWeeklyReport, deleteWeeklyReport, getWeeklySummary, exportWeeklyReportCSV, exportWeeklyReportXLSX,
  getWeeklyTrendsEndpoint, bulkExportEndpoint
} from '../controllers/weeklyReportController.js';
import { authenticateToken } from '../middleware/authMiddleware.js';
import { requirePermission } from '../middleware/rbacMiddleware.js';

const router = express.Router();

router.get('/weekly-reports/preview-absentees', authenticateToken, requirePermission('view_weekly_reports'), previewAbsentees);
router.post('/weekly-reports', authenticateToken, requirePermission('create_weekly_report'), createWeeklyReport);
router.get('/weekly-reports', authenticateToken, requirePermission('view_weekly_reports'), listWeeklyReports);
router.get('/weekly-reports/:id/details', authenticateToken, requirePermission('view_weekly_reports'), getWeeklyReportDetails);
router.put('/weekly-reports/:id', authenticateToken, requirePermission('update_weekly_report'), updateWeeklyReport);
router.delete('/weekly-reports/:id', authenticateToken, requirePermission('delete_weekly_report'), deleteWeeklyReport);

router.get('/weekly-reports/summary', authenticateToken, requirePermission('view_reports_summary'), getWeeklySummary);
router.get('/weekly-reports/:id/export/csv', authenticateToken, requirePermission('export_weekly_report'), exportWeeklyReportCSV);
router.get('/weekly-reports/:id/export/xlsx', authenticateToken, requirePermission('export_weekly_report'), exportWeeklyReportXLSX);

// extras
router.get('/weekly-reports/trends', authenticateToken, requirePermission('view_reports_summary'), getWeeklyTrendsEndpoint);
router.get('/weekly-reports/export/bulk', authenticateToken, requirePermission('export_weekly_report'), bulkExportEndpoint);

export default router;