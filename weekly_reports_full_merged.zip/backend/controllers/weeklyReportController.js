import * as model from '../models/weeklyReportModel.js';

export async function previewAbsentees(req, res) {
  try {
    const churchId = req.user?.church_id || Number(req.query.church_id);
    const cell_group_id = Number(req.query.cell_group_id);
    const week_start = req.query.week_start;
    const week_end = req.query.week_end || week_start;
    if (!churchId || !cell_group_id || !week_start) {
      return res.status(400).json({ message: 'church_id, cell_group_id and week_start are required' });
    }
    const rows = await model.computeAbsenteesUsingRoster(churchId, cell_group_id, week_start, week_end);
    return res.json(rows);
  } catch (err) {
    console.error('previewAbsentees error', err);
    return res.status(500).json({ message: err.message || 'Server error' });
  }
}

export async function createWeeklyReport(req, res) {
  try {
    const churchId = req.user?.church_id || req.body.church_id;
    if (!churchId) return res.status(403).json({ message: 'Missing church context' });
    const payload = { ...req.body, church_id: churchId, created_by: req.user?.id || req.user?.userId || null };
    const created = await model.createWeeklyReportWithAbsentees(payload);
    return res.status(201).json(created);
  } catch (err) {
    console.error('createWeeklyReport error', err);
    return res.status(500).json({ message: err.message || 'Server error' });
  }
}

export async function listWeeklyReports(req, res) {
  try {
    const churchId = req.user?.church_id || Number(req.query.church_id);
    if (!churchId) return res.status(403).json({ message: 'Missing church context' });
    const rows = await model.listWeeklyReports(churchId);
    return res.json(rows);
  } catch (err) {
    console.error('listWeeklyReports error', err);
    return res.status(500).json({ message: err.message || 'Server error' });
  }
}

export async function getWeeklyReportDetails(req, res) {
  try {
    const id = Number(req.params.id);
    const rows = await model.getWeeklyReportDetails(id);
    if (!rows || rows.length === 0) return res.status(404).json({ message: 'Not found' });
    return res.json(rows);
  } catch (err) {
    console.error('getWeeklyReportDetails error', err);
    return res.status(500).json({ message: err.message || 'Server error' });
  }
}

export async function updateWeeklyReport(req, res) {
  try {
    const id = Number(req.params.id);
    const updated = await model.updateWeeklyReport(id, { ...req.body, updated_by: req.user?.id || null });
    return res.json(updated);
  } catch (err) {
    console.error('updateWeeklyReport error', err);
    return res.status(500).json({ message: err.message || 'Server error' });
  }
}

export async function deleteWeeklyReport(req, res) {
  try {
    const id = Number(req.params.id);
    await model.softDeleteWeeklyReport(id, req.user?.id || null);
    return res.json({ success: true });
  } catch (err) {
    console.error('deleteWeeklyReport error', err);
    return res.status(500).json({ message: err.message || 'Server error' });
  }
}

export async function getWeeklySummary(req, res) {
  try {
    const churchId = req.user?.church_id || Number(req.query.church_id);
    const weekStart = req.query.week_start;
    if (!churchId || !weekStart) return res.status(400).json({ message: 'church_id and week_start required' });
    const summary = await model.getWeeklySummary(churchId, weekStart);
    return res.json(summary);
  } catch (err) {
    console.error('getWeeklySummary error', err);
    return res.status(500).json({ message: err.message || 'Server error' });
  }
}

export async function exportWeeklyReportCSV(req, res) {
  try {
    const id = Number(req.params.id);
    const csv = await model.exportWeeklyReportCSV(id);
    res.setHeader('Content-Disposition', `attachment; filename="weekly_report_${id}.csv"`);
    res.setHeader('Content-Type', 'text/csv');
    return res.send(csv);
  } catch (err) {
    console.error('exportWeeklyReportCSV error', err);
    return res.status(500).json({ message: err.message || 'Export failed' });
  }
}

export async function exportWeeklyReportXLSX(req, res) {
  try {
    const id = Number(req.params.id);
    const buffer = await model.exportWeeklyReportXLSX(id);
    res.setHeader('Content-Disposition', `attachment; filename="weekly_report_${id}.xlsx"`);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    return res.send(buffer);
  } catch (err) {
    console.error('exportWeeklyReportXLSX error', err);
    return res.status(500).json({ message: err.message || 'Export failed' });
  }
}

// Extra endpoints for trends and bulk export using model functions
export async function getWeeklyTrendsEndpoint(req, res) {
  try {
    const churchId = req.user?.church_id || Number(req.query.church_id);
    const nWeeks = Number(req.query.weeks || 12);
    if (!churchId) return res.status(400).json({ message: 'church_id required' });
    const trends = await model.getWeeklyTrends(churchId, nWeeks);
    return res.json(trends);
  } catch (err) {
    console.error('getWeeklyTrendsEndpoint error', err);
    return res.status(500).json({ message: err.message || 'Server error' });
  }
}

export async function bulkExportEndpoint(req, res) {
  try {
    const churchId = req.user?.church_id || Number(req.query.church_id);
    if (!churchId) return res.status(400).json({ message: 'church_id required' });
    const weeks = req.query.weeks ? Number(req.query.weeks) : 12;
    const weekStartsQ = `SELECT DISTINCT week_start FROM weekly_reports WHERE church_id = $1 AND deleted_at IS NULL ORDER BY week_start DESC LIMIT $2`;
    const { rows } = await model.dbClient.query(weekStartsQ, [churchId, weeks]);
    const weekStarts = rows.map(r => r.week_start);
    const buffer = await model.bulkExportWeeksXLSX(churchId, weekStarts);
    res.setHeader('Content-Disposition', `attachment; filename="weekly_reports_bulk_${new Date().toISOString().slice(0,10)}.xlsx"`);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    return res.send(buffer);
  } catch (err) {
    console.error('bulkExportEndpoint error', err);
    return res.status(500).json({ message: err.message || 'Export failed' });
  }
}