import cron from 'node-cron';
import fetch from 'node-fetch';
import fs from 'fs';
import path from 'path';

const API_URL = process.env.API_URL || 'http://localhost:5000';
const EXPORT_DIR = process.env.EXPORT_DIR || './exports';
const SCHED_TOKEN = process.env.SCHED_API_TOKEN || null;
const scheduleSpec = process.env.SCHEDULE_CRON || '0 2 * * 1';

export function startScheduler() {
  console.log('Starting scheduler with spec', scheduleSpec);
  cron.schedule(scheduleSpec, async () => {
    try {
      console.log('Running weekly bulk export job...');
      const qs = new URLSearchParams({ weeks: '12' });
      const url = `${API_URL}/api/weekly-reports/export/bulk?${qs.toString()}`;
      const headers = SCHED_TOKEN ? { Authorization: `Bearer ${SCHED_TOKEN}` } : {};
      const res = await fetch(url, { method: 'GET', headers });
      if (!res.ok) {
        console.error('Bulk export failed', res.statusText);
        return;
      }
      const arrayBuf = await res.arrayBuffer();
      fs.mkdirSync(EXPORT_DIR, { recursive: true });
      const filePath = path.join(EXPORT_DIR, `weekly_reports_bulk_${new Date().toISOString().slice(0,10)}.xlsx`);
      fs.writeFileSync(filePath, Buffer.from(arrayBuf));
      console.log('Exported to', filePath);
    } catch (err) {
      console.error('Scheduler job error', err);
    }
  });
}

if (require.main === module) {
  startScheduler();
}