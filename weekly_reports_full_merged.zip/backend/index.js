import express from 'express';
import bodyParser from 'body-parser';
import weeklyReportsRouter from './routes/weeklyReports.js';
import { startScheduler } from './tasks/scheduler.js';

const app = express();
app.use(bodyParser.json({ limit: '10mb' }));
app.use('/api', weeklyReportsRouter);

// start scheduler optionally if env var set
if (process.env.START_SCHEDULER === 'true') {
  try { startScheduler(); } catch (err) { console.error('scheduler start failed', err); }
}

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log('Server listening on', PORT));