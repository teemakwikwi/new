import db from '../config/db.js';
import { Parser as Json2csvParser } from 'json2csv';
import ExcelJS from 'exceljs';
import fs from 'fs';
import path from 'path';

/**
 * weeklyReportModel.js
 * Combined model: core functions + trends + bulk export + CSV/XLSX export
 */

/** Compute absentees by comparing roster vs attendance for the week */
export async function computeAbsenteesUsingRoster(churchId, cellGroupId, weekStart, weekEnd) {
  const sql = `
    WITH meetings AS (
      SELECT cm.cell_meeting_id, cm.meeting_date FROM cell_meetings cm
      WHERE cm.cell_group_id = $1 AND cm.meeting_date BETWEEN $2::date AND $3::date
    ),
    present_members AS (
      SELECT DISTINCT ar.member_id
      FROM attendance_records ar
      JOIN meetings m ON m.cell_meeting_id = ar.cell_meeting_id
      WHERE ar.member_id IS NOT NULL AND (ar.status='present' OR ar.status='excused')
    ),
    roster AS (
      SELECT cm.member_id FROM cell_members cm
      WHERE cm.cell_group_id = $1
        AND cm.deleted_at IS NULL
        AND ($3::date IS NULL OR (cm.joined_at IS NULL OR cm.joined_at <= $3::date))
        AND ($2::date IS NULL OR (cm.left_at IS NULL OR cm.left_at >= $2::date))
    ),
    absent_members AS (
      SELECT r.member_id FROM roster r
      LEFT JOIN present_members pm ON pm.member_id = r.member_id
      WHERE pm.member_id IS NULL
    ),
    present_visitors AS (
      SELECT DISTINCT ar.visitor_id FROM attendance_records ar
      JOIN meetings m ON m.cell_meeting_id = ar.cell_meeting_id
      WHERE ar.visitor_id IS NOT NULL AND (ar.status='present' OR ar.status='excused')
    ),
    active_visitors AS (
      SELECT v.visitor_id FROM visitors v WHERE v.cell_group_id = $1 AND v.deleted_at IS NULL
    ),
    absent_visitors AS (
      SELECT av.visitor_id FROM active_visitors av
      LEFT JOIN present_visitors pv ON pv.visitor_id = av.visitor_id
      WHERE pv.visitor_id IS NULL
    )
    SELECT 'member' AS type, am.member_id AS member_id, NULL::int AS visitor_id,
           m.first_name, m.surname, COALESCE(m.phone_number, '') AS phone, COALESCE(m.email,'') AS email,
           COALESCE(mf.count,0) AS followup_count, mf.last_followup_date
    FROM absent_members am
    LEFT JOIN members m ON m.member_id = am.member_id
    LEFT JOIN LATERAL (
      SELECT COUNT(*)::int AS count, MAX(fu.followup_date) AS last_followup_date
      FROM member_follow_ups fu WHERE fu.member_id = am.member_id
    ) mf ON TRUE

    UNION ALL

    SELECT 'visitor' AS type, NULL::int AS member_id, av.visitor_id,
           v.first_name, v.surname, COALESCE(v.contact_primary,'') AS phone, COALESCE(v.email,'') AS email,
           COALESCE(vf.count,0) AS followup_count, vf.last_followup_date
    FROM absent_visitors av
    LEFT JOIN visitors v ON v.visitor_id = av.visitor_id
    LEFT JOIN LATERAL (
      SELECT COUNT(*)::int AS count, MAX(fu.followup_date) AS last_followup_date
      FROM visitor_follow_ups fu WHERE fu.visitor_id = av.visitor_id
    ) vf ON TRUE
    ORDER BY surname NULLS LAST, first_name NULLS LAST;
  `;
  const { rows } = await db.query(sql, [cellGroupId, weekStart, weekEnd]);
  return rows;
}

/** Create weekly report with absentee details (transactional) */
export async function createWeeklyReportWithAbsentees(payload) {
  const client = await db.connect();
  try {
    await client.query('BEGIN');
    const insertReportSql = `
      INSERT INTO weekly_reports (
        church_id, cell_group_id, meeting_date, week_start, week_end, topic,
        attendance, attendee_names, visitors, visitors_count, testimonies, prayer_requests, follow_ups,
        challenges, support_needed, submitted_by, created_by, updated_by, created_at, updated_at
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8::jsonb,$9::jsonb,$10,$11,$12,$13,$14,$15,$16,$16,NOW(),NOW())
      RETURNING weekly_report_id;
    `;
    const attendeeNames = Array.isArray(payload.attendee_names) ? payload.attendee_names : [];
    const visitorsJson = Array.isArray(payload.visitors) ? payload.visitors : [];
    const repRes = await client.query(insertReportSql, [
      payload.church_id,
      payload.cell_group_id,
      payload.meeting_date || null,
      payload.week_start || payload.meeting_date || null,
      payload.week_end || payload.meeting_date || null,
      payload.topic || null,
      payload.attendance || (Array.isArray(payload.attendees) ? payload.attendees.length : 0),
      JSON.stringify(attendeeNames),
      JSON.stringify(visitorsJson),
      visitorsJson.length || 0,
      payload.testimonies || null,
      payload.prayer_requests || null,
      payload.follow_ups || null,
      payload.challenges || null,
      payload.support_needed || null,
      payload.submitted_by || payload.created_by || null
    ]);
    const weeklyReportId = repRes.rows[0].weekly_report_id;

    let details = Array.isArray(payload.details) ? payload.details : [];

    if ((!details || details.length === 0) && payload.auto_detect_absentees) {
      const absRows = await computeAbsenteesUsingRoster(payload.church_id, payload.cell_group_id, payload.week_start || payload.meeting_date, payload.week_end || payload.meeting_date);
      details = absRows.map(a => ({
        type: a.type,
        absentee_member_id: a.type === 'member' ? a.member_id : null,
        visitor_id: a.type === 'visitor' ? a.visitor_id : null,
        snapshot_followup_count: a.followup_count || 0,
        snapshot_last_followup_date: a.last_followup_date || null,
        reason: null
      }));
    }

    if ((!details || details.length === 0) && Array.isArray(payload.absentees) && payload.absentees.length) {
      details = payload.absentees.map(mid => ({
        type: 'member',
        absentee_member_id: mid,
        visitor_id: null,
        snapshot_followup_count: 0,
        snapshot_last_followup_date: null,
        reason: (payload.absenteeReasons || {})[mid] || null
      }));
    }

    const insertAbsenteeSql = `
      INSERT INTO absentees (
        church_id, cell_group_id, member_id, date_missed, reason, followup_status, followup_date,
        handled_by, created_by, updated_by, created_at, updated_at
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$9,NOW(),NOW())
      ON CONFLICT (church_id, cell_group_id, member_id, date_missed) DO UPDATE
      SET reason = EXCLUDED.reason, updated_at = NOW()
      RETURNING absentee_id;
    `;
    const insertDetailSql = `
      INSERT INTO weekly_report_details (
        weekly_report_id, absentee_id, visitor_id, followup_action, created_by,
        snapshot_followup_count, snapshot_last_followup_date, role_snapshot, created_at, updated_at
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,NOW(),NOW())
      RETURNING weekly_report_detail_id;
    `;

    for (const d of details) {
      if (d.type === 'member' || d.absentee_member_id) {
        const dateMissed = payload.week_start || payload.meeting_date || new Date().toISOString().slice(0,10);
        const reason = d.reason || (payload.absenteeReasons || {})[d.absentee_member_id] || null;
        const resA = await client.query(insertAbsenteeSql, [
          payload.church_id,
          payload.cell_group_id,
          d.absentee_member_id,
          dateMissed,
          reason,
          d.followup_status || 'pending',
          d.followup_date || null,
          d.handled_by || null,
          payload.created_by || null
        ]);
        const absenteeId = resA.rows[0].absentee_id;
        await client.query(insertDetailSql, [
          weeklyReportId,
          absenteeId,
          null,
          d.followup_action || null,
          payload.created_by || null,
          d.snapshot_followup_count || 0,
          d.snapshot_last_followup_date || null,
          d.role_snapshot || null
        ]);
      } else if (d.type === 'visitor' || d.visitor_id) {
        await client.query(insertDetailSql, [
          weeklyReportId,
          null,
          d.visitor_id,
          d.followup_action || null,
          payload.created_by || null,
          d.snapshot_followup_count || 0,
          d.snapshot_last_followup_date || null,
          d.role_snapshot || null
        ]);
      }
    }

    await client.query('COMMIT');
    return { weekly_report_id: weeklyReportId };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

/** List weekly reports for a church */
export async function listWeeklyReports(churchId) {
  const q = `
    SELECT weekly_report_id AS id, church_id, cell_group_id, meeting_date, week_start, week_end, topic, attendance, created_at
    FROM weekly_reports
    WHERE church_id = $1 AND deleted_at IS NULL
    ORDER BY week_start DESC, meeting_date DESC
  `;
  const { rows } = await db.query(q, [churchId]);
  return rows;
}

/** Get report details */
export async function getWeeklyReportDetails(weeklyReportId) {
  const q = `
    SELECT wr.weekly_report_id, wr.*, wrd.weekly_report_detail_id, wrd.absentee_id, wrd.visitor_id, wrd.followup_action,
           wrd.snapshot_followup_count, wrd.snapshot_last_followup_date, wrd.role_snapshot,
           a.member_id AS absentee_member_id, m.first_name AS member_first_name, m.surname AS member_surname,
           v.visitor_id AS visitor_id_snapshot, v.first_name AS visitor_first_name, v.surname AS visitor_surname
    FROM weekly_reports wr
    LEFT JOIN weekly_report_details wrd ON wrd.weekly_report_id = wr.weekly_report_id AND wrd.deleted_at IS NULL
    LEFT JOIN absentees a ON a.absentee_id = wrd.absentee_id AND a.deleted_at IS NULL
    LEFT JOIN members m ON m.member_id = a.member_id
    LEFT JOIN visitors v ON v.visitor_id = wrd.visitor_id
    WHERE wr.weekly_report_id = $1 AND wr.deleted_at IS NULL
  `;
  const { rows } = await db.query(q, [weeklyReportId]);
  return rows;
}

/** Update weekly report header fields */
export async function updateWeeklyReport(weeklyReportId, payload) {
  const sets = [];
  const vals = [];
  let i = 1;
  for (const k of ['topic','attendance','testimonies','prayer_requests','follow_ups','challenges','support_needed','meeting_date','submitted_by']) {
    if (payload[k] !== undefined) {
      sets.push(`${k} = $${i}`);
      vals.push(payload[k]);
      i++;
    }
  }
  if (sets.length === 0) throw new Error('No fields to update');
  vals.push(payload.updated_by || null);
  vals.push(weeklyReportId);
  const sql = `UPDATE weekly_reports SET ${sets.join(',')}, updated_at = NOW(), updated_by = $${i} WHERE weekly_report_id = $${i+1} AND deleted_at IS NULL RETURNING *`;
  const { rows } = await db.query(sql, vals);
  return rows[0];
}

/** Soft delete report */
export async function softDeleteWeeklyReport(weeklyReportId, deletedBy) {
  const sql = `UPDATE weekly_reports SET deleted_at = NOW(), deleted_by = $1 WHERE weekly_report_id = $2`;
  await db.query(sql, [deletedBy || null, weeklyReportId]);
  return true;
}

/** Summary for a week */
export async function getWeeklySummary(churchId, weekStart) {
  const q = `
    SELECT
      wr.weekly_report_id,
      wr.cell_group_id,
      cg.name AS cell_group,
      wr.attendance,
      wr.visitors_count,
      (SELECT COUNT(*) FROM weekly_report_details wrd JOIN absentees a ON a.absentee_id = wrd.absentee_id WHERE wrd.weekly_report_id = wr.weekly_report_id) AS absentees_count
    FROM weekly_reports wr
    LEFT JOIN cell_groups cg ON cg.cell_group_id = wr.cell_group_id
    WHERE wr.church_id = $1
      AND wr.week_start = $2::date
      AND wr.deleted_at IS NULL
  `;
  const { rows } = await db.query(q, [churchId, weekStart]);
  if (!rows || rows.length === 0) return { rows: [], top: null, lowest: null, mostVisitors: null, mostAbsentees: null };
  const top = rows.slice().sort((a,b)=> (b.attendance||0) - (a.attendance||0))[0];
  const lowest = rows.slice().sort((a,b)=> (a.attendance||0) - (b.attendance||0))[0];
  const mostVisitors = rows.slice().sort((a,b)=> (b.visitors_count||0) - (a.visitors_count||0))[0];
  const mostAbsentees = rows.slice().sort((a,b)=> (b.absentees_count||0) - (a.absentees_count||0))[0];
  return { rows, top, lowest, mostVisitors, mostAbsentees };
}

/** Export single report to CSV */
export async function exportWeeklyReportCSV(weeklyReportId) {
  const details = await getWeeklyReportDetails(weeklyReportId);
  if (!details || !details.length) throw new Error('Report not found or has no details');
  const rows = details.map(d => ({
    type: d.absentee_member_id ? 'absentee' : (d.visitor_id ? 'visitor' : 'detail'),
    member_first_name: d.member_first_name || '',
    member_surname: d.member_surname || '',
    visitor_first_name: d.visitor_first_name || '',
    visitor_surname: d.visitor_surname || '',
    followup_action: d.followup_action || ''
  }));
  const parser = new Json2csvParser({ header: true });
  const csv = parser.parse(rows);
  return csv;
}

/** Export single report to XLSX buffer */
export async function exportWeeklyReportXLSX(weeklyReportId) {
  const details = await getWeeklyReportDetails(weeklyReportId);
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Weekly Report');
  ws.addRow(['Cell Group ID', details[0]?.cell_group_id || '']);
  ws.addRow(['Meeting Date', details[0]?.meeting_date || '']);
  ws.addRow(['Topic', details[0]?.topic || '']);
  ws.addRow([]);
  ws.addRow(['Type', 'Member First', 'Member Last', 'Visitor First', 'Visitor Last', 'Followup Action']);
  for (const d of details) {
    ws.addRow([d.absentee_member_id ? 'absentee' : (d.visitor_id ? 'visitor' : 'detail'), d.member_first_name || '', d.member_surname || '', d.visitor_first_name || '', d.visitor_surname || '', d.followup_action || '']);
  }
  const buffer = await wb.xlsx.writeBuffer();
  return buffer;
}

/** Trends (last N weeks) */
export async function getWeeklyTrends(churchId, nWeeks = 12) {
  const weeksQ = `SELECT DISTINCT week_start FROM weekly_reports WHERE church_id = $1 AND deleted_at IS NULL ORDER BY week_start DESC LIMIT $2`;
  const weeksRes = await db.query(weeksQ, [churchId, nWeeks]);
  const weekStarts = weeksRes.rows.map(r => r.week_start).reverse();
  if (!weekStarts.length) return [];
  const results = [];
  for (const ws of weekStarts) {
    const q = `
      SELECT 
        COALESCE(SUM(attendance),0)::int AS attendance_total,
        COALESCE(SUM(visitors_count),0)::int AS visitors_total,
        COALESCE(SUM(
          (SELECT COUNT(*) FROM weekly_report_details wrd JOIN absentees a ON a.absentee_id = wrd.absentee_id WHERE wrd.weekly_report_id = wr.weekly_report_id)
        ),0)::int AS absentees_total
      FROM weekly_reports wr
      WHERE wr.church_id = $1 AND wr.week_start = $2::date AND wr.deleted_at IS NULL
    `;
    const r = await db.query(q, [churchId, ws]);
    results.push({ week_start: ws, attendance_total: r.rows[0].attendance_total || 0, visitors_total: r.rows[0].visitors_total || 0, absentees_total: r.rows[0].absentees_total || 0 });
  }
  return results;
}

/** Bulk export weeks to XLSX buffer */
export async function bulkExportWeeksXLSX(churchId, weekStarts = []) {
  if (!Array.isArray(weekStarts) || weekStarts.length === 0) throw new Error('weekStarts required');
  const wb = new ExcelJS.Workbook();
  for (const ws of weekStarts) {
    const reportsQ = `SELECT weekly_report_id, cell_group_id, topic, attendance, visitors_count, meeting_date FROM weekly_reports WHERE church_id = $1 AND week_start = $2::date AND deleted_at IS NULL`;
    const reportsRes = await db.query(reportsQ, [churchId, ws]);
    const sheet = wb.addWorksheet(ws.toISOString().slice(0,10));
    sheet.addRow(['Report ID','Cell Group ID','Topic','Attendance','Visitors','Meeting Date']);
    for (const rep of reportsRes.rows) {
      sheet.addRow([rep.weekly_report_id, rep.cell_group_id, rep.topic || '', rep.attendance || 0, rep.visitors_count || 0, rep.meeting_date ? rep.meeting_date.toISOString().slice(0,10) : '']);
      const detQ = `SELECT wrd.weekly_report_detail_id, wrd.absentee_id, wrd.visitor_id, m.first_name as member_first, m.surname as member_last, v.first_name as visitor_first, v.surname as visitor_last, wrd.followup_action FROM weekly_report_details wrd LEFT JOIN absentees a ON a.absentee_id = wrd.absentee_id LEFT JOIN members m ON m.member_id = a.member_id LEFT JOIN visitors v ON v.visitor_id = wrd.visitor_id WHERE wrd.weekly_report_id = $1 AND wrd.deleted_at IS NULL`;
      const detRes = await db.query(detQ, [rep.weekly_report_id]);
      if (detRes.rows.length) {
        sheet.addRow(['-- Details --']);
        sheet.addRow(['Detail ID','Absentee ID','Member First','Member Last','Visitor ID','Visitor First','Visitor Last','Action']);
        for (const d of detRes.rows) {
          sheet.addRow([d.weekly_report_detail_id, d.absentee_id || '', d.member_first || '', d.member_last || '', d.visitor_id || '', d.visitor_first || '', d.visitor_last || '', d.followup_action || '']);
        }
      }
      sheet.addRow([]);
    }
  }
  const buffer = await wb.xlsx.writeBuffer();
  return buffer;
}

/** Scheduler helper that writes bulk export to disk */
export async function writeBulkExportForLastNWeeks(churchId, nWeeks = 12, outputDir = './exports') {
  const weekStartsQ = `SELECT DISTINCT week_start FROM weekly_reports WHERE church_id = $1 AND deleted_at IS NULL ORDER BY week_start DESC LIMIT $2`;
  const wsRes = await db.query(weekStartsQ, [churchId, nWeeks]);
  const weekStarts = wsRes.rows.map(r => r.week_start);
  if (!weekStarts.length) throw new Error('No weeks found to export');
  const buffer = await bulkExportWeeksXLSX(churchId, weekStarts);
  fs.mkdirSync(outputDir, { recursive: true });
  const fname = `weekly_reports_bulk_${new Date().toISOString().slice(0,10)}.xlsx`;
  const outPath = path.join(outputDir, fname);
  fs.writeFileSync(outPath, buffer);
  return outPath;
}

// expose db for controller convenience if needed
export const dbClient = db;