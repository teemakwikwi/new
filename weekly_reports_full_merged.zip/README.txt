Merged weekly reports package (merged extras).
Files are placed under backend/ and frontend/src/components + frontend/src/services.
Install backend deps: npm i express pg body-parser jsonwebtoken json2csv exceljs node-cron node-fetch
Install frontend deps: npm i recharts
Start backend: node backend/index.js (set env START_SCHEDULER=true to start scheduler)