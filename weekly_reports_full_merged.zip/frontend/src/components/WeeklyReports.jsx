import React, { useEffect, useState } from 'react';
import { Box, Typography, Button, Modal, TextField, Grid, Paper, List, ListItem, ListItemText, IconButton, Chip } from '@mui/material';
import DownloadIcon from '@mui/icons-material/Download';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import WeeklyTrendsChart from './WeeklyTrendsChart';
import {
  previewAbsentees, createWeeklyReport, getWeeklyReports, getWeeklyReportDetails,
  getWeeklyTrends, bulkExportWeeks, exportWeeklyReportCSV, exportWeeklyReportXLSX
} from '../services/weeklyReportService';
import { getCellGroups, getCellGroupMembers } from '../services/cellGroupService';
import { listVisitors } from '../services/visitorService';

export default function WeeklyReports() {
  const [reports, setReports] = useState([]);
  const [groups, setGroups] = useState([]);
  const [visitors, setVisitors] = useState([]);
  const [members, setMembers] = useState([]);
  const [open, setOpen] = useState(false);
  const [fields, setFields] = useState({ cell_group_id:'', date_of_meeting:'', topic_taught:'', attendees:[], absentees:[], visitor_ids:[], testimonies:'', prayer_requests:'', follow_ups:'', challenges:'', support_needed:'' });
  const [preview, setPreview] = useState([]);
  const [trends, setTrends] = useState([]);

  useEffect(()=>{ (async()=>{
    setGroups(await getCellGroups()||[]);
    setReports(await getWeeklyReports()||[]);
    setVisitors(await listVisitors()||[]);
    try { setTrends(await getWeeklyTrends(12) || []); } catch(e){}
  })() },[]);

  useEffect(()=>{ if (!fields.cell_group_id) return; (async ()=>{ setMembers(await getCellGroupMembers(fields.cell_group_id)||[]); })() }, [fields.cell_group_id]);

  async function handlePreview() {
    if (!fields.cell_group_id || !fields.date_of_meeting) return alert('select group/date');
    const rows = await previewAbsentees(fields.cell_group_id, fields.date_of_meeting, fields.date_of_meeting);
    setPreview(rows || []);
  }

  function acceptPreview(){ const memberIds = preview.filter(p=>p.type==='member').map(p=>p.member_id); setFields(f=>({...f, absentees: memberIds})); }

  async function save(){ await createWeeklyReport({...fields, auto_detect_absentees: true}); setOpen(false); setReports(await getWeeklyReports()); }

  async function handleBulkExport(){ const blob = await bulkExportWeeks(12); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `weekly_reports_bulk_${new Date().toISOString().slice(0,10)}.xlsx`; a.click(); URL.revokeObjectURL(url); }

  return (
    <Box sx={{ p:3 }}>
      <Typography variant="h4">Weekly Reports</Typography>
      <Box sx={{ display:'flex', gap:2, my:2 }}>
        <Button variant="contained" onClick={()=>setOpen(true)}>Add Report</Button>
        <Button variant="outlined" startIcon={<DownloadIcon />} onClick={handleBulkExport}>Bulk Export (12 weeks)</Button>
      </Box>
      <WeeklyTrendsChart data={trends} />
      <Grid container spacing={2}>
        <Grid item xs={12} md={4}>
          <Paper sx={{ p:2, maxHeight: '70vh', overflow:'auto' }}>
            <List>
              {reports.map(r=> (<ListItem key={r.id}><ListItemText primary={r.topic || 'Report'} secondary={r.week_start || r.meeting_date} /></ListItem>))}
            </List>
          </Paper>
        </Grid>
        <Grid item xs={12} md={8}><Paper sx={{ p:2 }}>Select a report to see details</Paper></Grid>
      </Grid>

      <Modal open={open} onClose={()=>setOpen(false)}>
        <Box sx={{ position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)', width:800, bgcolor:'background.paper', p:3 }}>
          <Typography variant="h6">Add Weekly Report</Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} md={4}><TextField select label="Cell Group" value={fields.cell_group_id} onChange={e=>setFields(f=>({...f, cell_group_id:e.target.value}))} fullWidth SelectProps={{ native:true }}>
              <option value=''>Select</option>{groups.map(g=> <option value={g.id} key={g.id}>{g.name}</option>)}
            </TextField></Grid>
            <Grid item xs={12} md={4}><TextField label="Meeting Date" type="date" value={fields.date_of_meeting} onChange={e=>setFields(f=>({...f, date_of_meeting:e.target.value}))} InputLabelProps={{shrink:true}} fullWidth /></Grid>
            <Grid item xs={12} md={4}><TextField label="Topic" value={fields.topic_taught} onChange={e=>setFields(f=>({...f, topic_taught:e.target.value}))} fullWidth /></Grid>

            <Grid item xs={12}>
              <Box sx={{ display:'flex', gap:1 }}>
                <Button variant="outlined" onClick={handlePreview}>Preview Absentees</Button>
                <Button variant="text" onClick={acceptPreview}>Accept Preview</Button>
              </Box>
              {preview.length>0 && <Box sx={{ mt:1 }}>{preview.map((p,i)=>(<Chip key={i} label={`${p.first_name} ${p.surname}`} sx={{mr:1}}/>))}</Box>}
            </Grid>

            <Grid item xs={12}><Box sx={{ display:'flex', justifyContent:'flex-end', gap:1 }}><Button onClick={()=>setOpen(false)}>Cancel</Button><Button variant="contained" onClick={save}>Save</Button></Box></Grid>
          </Grid>
        </Box>
      </Modal>
    </Box>
  );
}