import React from 'react';
import { Card, CardContent, Typography } from '@mui/material';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from 'recharts';

export default function WeeklyTrendsChart({ data }) {
  if (!data || data.length === 0) return null;
  const chartData = data.map(d => ({ week: new Date(d.week_start).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }), attendance: d.attendance_total, visitors: d.visitors_total, absentees: d.absentees_total }));
  return (
    <Card variant="outlined" sx={{ mb:2 }}>
      <CardContent>
        <Typography variant="h6">Weekly Trends</Typography>
        <ResponsiveContainer width="100%" height={260}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="week" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="attendance" stroke="#1976d2" />
            <Line type="monotone" dataKey="visitors" stroke="#2e7d32" />
            <Line type="monotone" dataKey="absentees" stroke="#d32f2f" />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}