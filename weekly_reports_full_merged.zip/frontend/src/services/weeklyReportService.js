const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

async function handleResponse(res) {
  if (!res.ok) {
    let msg = 'Request failed';
    try { const j = await res.json(); msg = j.message || j.error || msg; } catch {}
    throw new Error(msg);
  }
  const ct = res.headers.get('content-type') || '';
  if (ct.includes('application/vnd.openxmlformats') || ct.includes('text/csv') || ct.includes('application/octet-stream')) {
    const blob = await res.blob();
    return blob;
  }
  return res.json();
}

export async function previewAbsentees(cell_group_id, week_start, week_end = null) {
  const qs = new URLSearchParams({ cell_group_id, week_start, week_end: week_end || week_start }).toString();
  const res = await fetch(`${API_URL}/api/weekly-reports/preview-absentees?${qs}`, { credentials: 'include' });
  return handleResponse(res);
}

export async function createWeeklyReport(payload) {
  const res = await fetch(`${API_URL}/api/weekly-reports`, {
    method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
  });
  return handleResponse(res);
}

export async function getWeeklyReports() {
  const res = await fetch(`${API_URL}/api/weekly-reports`, { credentials: 'include' });
  return handleResponse(res);
}

export async function getWeeklyReportDetails(id) {
  const res = await fetch(`${API_URL}/api/weekly-reports/${id}/details`, { credentials: 'include' });
  return handleResponse(res);
}

export async function updateWeeklyReport(id, payload) {
  const res = await fetch(`${API_URL}/api/weekly-reports/${id}`, { method: 'PUT', credentials: 'include', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
  return handleResponse(res);
}

export async function deleteWeeklyReport(id) {
  const res = await fetch(`${API_URL}/api/weekly-reports/${id}`, { method: 'DELETE', credentials: 'include' });
  return handleResponse(res);
}

export async function getWeeklySummary(week_start) {
  const qs = new URLSearchParams({ week_start }).toString();
  const res = await fetch(`${API_URL}/api/weekly-reports/summary?${qs}`, { credentials: 'include' });
  return handleResponse(res);
}

export async function exportWeeklyReportCSV(id) {
  const res = await fetch(`${API_URL}/api/weekly-reports/${id}/export/csv`, { credentials: 'include' });
  return handleResponse(res);
}

export async function exportWeeklyReportXLSX(id) {
  const res = await fetch(`${API_URL}/api/weekly-reports/${id}/export/xlsx`, { credentials: 'include' });
  return handleResponse(res);
}

export async function getWeeklyTrends(weeks = 12) {
  const qs = new URLSearchParams({ weeks: String(weeks) }).toString();
  const res = await fetch(`${API_URL}/api/weekly-reports/trends?${qs}`, { credentials: 'include' });
  return handleResponse(res);
}

export async function bulkExportWeeks(weeks = 12) {
  const qs = new URLSearchParams({ weeks: String(weeks) }).toString();
  const res = await fetch(`${API_URL}/api/weekly-reports/export/bulk?${qs}`, { credentials: 'include' });
  return handleResponse(res);
}